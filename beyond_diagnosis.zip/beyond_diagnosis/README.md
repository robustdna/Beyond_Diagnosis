# Beyond Diagnosis: Evaluating Recommendation Stability under Counterfactual Skin-Tone Perturbations  

This supplementary package contains the implementation code used in the submitted AACL paper.  

## Directory Structure


supplementary_code_/
├── README.md
├── codes/
│   ├── derma_biollavanext.py
│   ├── derma_claude46.py
│   ├── derma_deepseekvl2.py
│   ├── derma_gemini3.py
│   ├── derma_gemma4.py
│   ├── derma_gpt54.py
│   ├── derma_medgemma.py
│   ├── derma_medgemma_large.py
│   ├── derma_molmo2.py
│   └── derma_qwen36.py
├── prompt/
│   └── prompt.txt
├── utils/
│   └── utils.py
└── requirements.txt

## Setup

We recommend Python 3.10+.

Install dependencies as needed for the corresponding models and APIs.

## Full Dataset Access

Due to the supplementary material size limitation, the full dataset is hosted separately at the following anonymous view-only link:

https://drive.google.com/file/d/1-WpttpLIpyI1bmZLT2qn3XZEIr13LDM9/view?usp=sharing


The link does not require sign-in.
After downloading the dataset, place the extracted files in the appropriate local directory before running the scripts.


## Usage

Example execution:

```bash
python codes/derma_gpt54.py
```

Other scripts correspond to different evaluated models described in the paper.

## Prompt File

The prompts used in the experiments are provided in:

```text
prompt/prompt.txt
```

## Notes

* Large datasets and intermediate outputs are omitted due to size constraints.
* API credentials and private information have been removed.

