#!/usr/bin/env python3
# ============================================================
# Dermatology Skin-tone Perturbation Audit
# Qwen3.6 Version
#
# Uses:
#   utils.py
#     - PROMPT
#     - parse_output
#     - make_pairwise_deltas
# ============================================================

import os
import re
import json
import time
import traceback
from pathlib import Path
from datetime import datetime

import torch
import pandas as pd
from tqdm import tqdm
from PIL import Image
from transformers import AutoProcessor, AutoModelForImageTextToText

from utils import PROMPT, parse_output, make_pairwise_deltas


# -------------------------
# Config
# -------------------------
MODEL_ID = "Qwen/Qwen3.6-35B-A3B"
MODEL_TAG = "qwen3_6_35b_a3b"

IMG_ROOT = Path("")
OUT_DIR = Path("")
OUT_DIR.mkdir(parents=True, exist_ok=True)

DISEASES = ["acne", "benign nevus", "eczema", "psoriasis", "tinea", "vitiligo"]
IMG_EXTS = {".jpg", ".jpeg", ".png", ".webp", ".bmp", ".tif", ".tiff"}

MAX_NEW_TOKENS = 384
MAX_RETRIES = 3
DO_SAMPLE = False
IMAGE_MAX_SIZE = 1024

SAVE_EVERY = 10
PRINT_EVERY = 5
SHOW_OUTPUT_PREVIEW = True

RUN_ID = datetime.now().strftime("%Y%m%d_%H%M%S")

RESULTS_JSONL = OUT_DIR / f"{MODEL_TAG}_derma_raw_{RUN_ID}.jsonl"
PARSED_CSV = OUT_DIR / f"{MODEL_TAG}_derma_parsed_{RUN_ID}.csv"
PAIRED_CSV = OUT_DIR / f"{MODEL_TAG}_derma_paired_deltas_{RUN_ID}.csv"
PROGRESS_CSV = OUT_DIR / f"{MODEL_TAG}_derma_parsed_PROGRESS_{RUN_ID}.csv"
MANIFEST_CSV = OUT_DIR / f"{MODEL_TAG}_derma_manifest_{RUN_ID}.csv"

print(f"{RUN_ID} / {RESULTS_JSONL} / {PARSED_CSV}")


# -------------------------
# Helpers
# -------------------------
def append_jsonl(path, obj):
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(obj, ensure_ascii=False) + "\n")


def cleanup_cuda():
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
        torch.cuda.ipc_collect()


def extract_number(path: Path) -> int:
    m = re.search(r"_(\d+)$", path.stem)
    if not m:
        raise ValueError(f"Cannot extract numeric suffix from {path.name}")
    return int(m.group(1))


def infer_case_and_tone(path: Path):
    n = extract_number(path)
    case_index = ((n - 1) // 4) + 1
    tone_index = ((n - 1) % 4) + 1

    return (
        f"{path.parent.name}_case_{case_index:03d}",
        f"tone{tone_index}",
        tone_index,
    )


def list_images():
    rows = []

    for disease in DISEASES:
        d = IMG_ROOT / disease

        if not d.exists():
            print(f"[WARN] missing folder: {d}")
            continue

        paths = sorted(
            [p for p in d.iterdir() if p.suffix.lower() in IMG_EXTS],
            key=lambda p: extract_number(p),
        )

        for p in paths:
            case_id, tone, tone_index = infer_case_and_tone(p)

            rows.append({
                "disease_folder": disease,
                "image_path": str(p),
                "filename": p.name,
                "image_number": extract_number(p),
                "case_id": case_id,
                "tone": tone,
                "tone_index": tone_index,
            })

    return pd.DataFrame(rows)


def load_image_for_qwen(image_path):
    image = Image.open(image_path).convert("RGB")
    image.thumbnail((IMAGE_MAX_SIZE, IMAGE_MAX_SIZE))
    return image


def clean_qwen_response(text):
    if text is None:
        return ""

    text = text.strip()
    text = text.replace("<|endoftext|>", "")
    text = text.replace("<|im_end|>", "")
    text = text.replace("<|end|>", "")
    text = text.replace("<|assistant|>", "")
    return text.strip()


def build_qwen_prompt(prompt):
    return (
        "Follow the requested clinical output format exactly. "
        "Do not add extra sections.\n\n"
        + prompt
    )


# -------------------------
# Load Qwen3.6
# -------------------------
print("\n[Load] Loading Qwen3.6 processor...")

processor = AutoProcessor.from_pretrained(
    MODEL_ID,
    trust_remote_code=True,
    use_fast=False,
)

print("[Load] Loading Qwen3.6 model...")

model = AutoModelForImageTextToText.from_pretrained(
    MODEL_ID,
    trust_remote_code=True,
    torch_dtype=torch.bfloat16 if torch.cuda.is_available() else torch.float32,
    device_map="auto" if torch.cuda.is_available() else None,
)

if not torch.cuda.is_available():
    model = model.to("cpu")

model.eval()

print("[Load] CUDA available:", torch.cuda.is_available())
print("[Load] CUDA device count:", torch.cuda.device_count())

if torch.cuda.is_available():
    for gi in range(torch.cuda.device_count()):
        print(f"[Load] GPU {gi}:", torch.cuda.get_device_name(gi))

print("[Load] Model loaded.")


# -------------------------
# Inference
# -------------------------
@torch.no_grad()
def run_model(image_path):
    image = load_image_for_qwen(image_path)
    prompt = build_qwen_prompt(PROMPT)

    messages = [
        {
            "role": "user",
            "content": [
                {"type": "image", "image": image},
                {"type": "text", "text": prompt},
            ],
        }
    ]

    inputs = processor.apply_chat_template(
        messages,
        tokenize=True,
        add_generation_prompt=True,
        return_tensors="pt",
        return_dict=True,
    )

    inputs = {
        k: v.to(model.device) if torch.is_tensor(v) else v
        for k, v in inputs.items()
    }

    generated_ids = model.generate(
        **inputs,
        max_new_tokens=MAX_NEW_TOKENS,
        do_sample=DO_SAMPLE,
    )

    generated_tokens = generated_ids[0, inputs["input_ids"].size(1):]

    output_text = processor.tokenizer.decode(
        generated_tokens,
        skip_special_tokens=True,
    ).strip()

    return clean_qwen_response(output_text)


# -------------------------
# Main
# -------------------------
manifest = list_images()
manifest.to_csv(MANIFEST_CSV, index=False)

print(f"Images found: {len(manifest)}")
print(manifest.groupby("disease_folder").size())
print(f"Manifest saved to: {MANIFEST_CSV}")
print(f"Live JSONL will be saved to: {RESULTS_JSONL}")
print(f"Progress CSV will be saved every {SAVE_EVERY} images to: {PROGRESS_CSV}")

rows = []
n_success = 0
n_error = 0
start_time = time.time()

print("Start inference...")

for i, (_, r) in enumerate(tqdm(manifest.iterrows(), total=len(manifest)), start=1):
    pct = 100 * i / len(manifest)
    last_error = None

    for attempt in range(MAX_RETRIES):
        try:
            output = run_model(r["image_path"])
            parsed = parse_output(output)

            row = {
                **r.to_dict(),
                "model_id": MODEL_ID,
                "prompt": PROMPT,
                "temperature": 0,
                "max_new_tokens": MAX_NEW_TOKENS,
                **parsed,
                "error": "",
            }

            append_jsonl(RESULTS_JSONL, row)
            rows.append(row)
            n_success += 1

            if SHOW_OUTPUT_PREVIEW and (i <= 3 or i % PRINT_EVERY == 0):
                print("\n" + "=" * 80)
                print(f"[{i}/{len(manifest)} | {pct:.1f}%] SUCCESS")
                print(f"file: {r['filename']}")
                print(f"disease: {r['disease_folder']} | case: {r['case_id']} | tone: {r['tone']}")
                print("-" * 80)
                print(output[:1200])
                print("=" * 80)

            break

        except torch.cuda.OutOfMemoryError as e:
            last_error = e
            cleanup_cuda()

            if attempt < MAX_RETRIES - 1:
                wait = min(90, 2 ** attempt * 5)
                print(
                    f"\n[CUDA OOM Retry] file={r['filename']} "
                    f"attempt={attempt + 1}/{MAX_RETRIES} wait={wait}s"
                )
                time.sleep(wait)
            else:
                err = traceback.format_exc()

                row = {
                    **r.to_dict(),
                    "model_id": MODEL_ID,
                    "prompt": PROMPT,
                    "temperature": 0,
                    "max_new_tokens": MAX_NEW_TOKENS,
                    "raw_output": "",
                    "error": err,
                }

                append_jsonl(RESULTS_JSONL, row)
                rows.append(row)
                n_error += 1

                print("\n" + "!" * 80)
                print(f"[{i}/{len(manifest)} | {pct:.1f}%] FAILED CUDA OOM")
                print(f"file: {r['filename']}")
                print(f"error: {repr(last_error)}")
                print("!" * 80)

        except Exception as e:
            last_error = e
            cleanup_cuda()

            if attempt < MAX_RETRIES - 1:
                wait = min(90, 2 ** attempt * 5)
                print(
                    f"\n[Retry] file={r['filename']} "
                    f"attempt={attempt + 1}/{MAX_RETRIES} "
                    f"error={repr(e)} wait={wait}s"
                )
                time.sleep(wait)
            else:
                err = traceback.format_exc()

                row = {
                    **r.to_dict(),
                    "model_id": MODEL_ID,
                    "prompt": PROMPT,
                    "temperature": 0,
                    "max_new_tokens": MAX_NEW_TOKENS,
                    "raw_output": "",
                    "error": err,
                }

                append_jsonl(RESULTS_JSONL, row)
                rows.append(row)
                n_error += 1

                print("\n" + "!" * 80)
                print(f"[{i}/{len(manifest)} | {pct:.1f}%] FAILED")
                print(f"file: {r['filename']}")
                print(f"error: {repr(e)}")
                print("!" * 80)

    if i % SAVE_EVERY == 0:
        tmp_df = pd.DataFrame(rows)
        tmp_df.to_csv(PROGRESS_CSV, index=False)

        elapsed = time.time() - start_time
        avg_sec = elapsed / max(i, 1)

        print("\n" + "-" * 80)
        print(f"[PROGRESS SAVE] {i}/{len(manifest)} = {pct:.1f}%")
        print(f"success: {n_success} | errors: {n_error}")
        print(f"avg sec/image: {avg_sec:.2f}")
        print(f"saved: {PROGRESS_CSV}")
        print(f"jsonl live file: {RESULTS_JSONL}")
        print("-" * 80)


# -------------------------
# Final save
# -------------------------
df = pd.DataFrame(rows)

df.to_csv(PARSED_CSV, index=False)
df.to_csv(PROGRESS_CSV, index=False)

delta_df = make_pairwise_deltas(df)
delta_df.to_csv(PAIRED_CSV, index=False)

print("\nDONE")
print(f"Raw JSONL:      {RESULTS_JSONL}")
print(f"Parsed CSV:     {PARSED_CSV}")
print(f"Progress CSV:   {PROGRESS_CSV}")
print(f"Paired deltas:  {PAIRED_CSV}")

print("\nQuick summary:")
print("Rows:", len(df))
print("Cases:", df[["disease_folder", "case_id"]].drop_duplicates().shape[0])
print("Success:", n_success)
print("Errors:", n_error)

if len(delta_df) > 0:
    print("\nDiagnosis flip rate:")
    print(delta_df["diagnosis_flip"].mean())

    delta_cols = [c for c in delta_df.columns if c.startswith("delta_")]

    print("\nMean paired deltas:")
    print(
        delta_df[delta_cols]
        .mean(numeric_only=True)
        .sort_values(ascending=False)
        .head(20)
    )
