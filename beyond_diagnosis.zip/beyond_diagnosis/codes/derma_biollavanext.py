#!/usr/bin/env python3
# ============================================================
# Dermatology Skin-tone Perturbation Audit
# BioMed LLaVA-NeXT Version
#
# Uses:
#   utils.py
#     - PROMPT
#     - parse_output
#     - make_pairwise_deltas
# ============================================================

import os
import re
import json
import time
import traceback
from pathlib import Path
from datetime import datetime
print("[DEBUG 00] datetime", flush=True)
import torch
print("[DEBUG 01] torch", flush=True)
import pandas as pd
print("[DEBUG 02] pandas", flush=True)
from tqdm import tqdm
print("[DEBUG 03] tqdm", flush=True)
from PIL import Image
print("[DEBUG 04] PIL", flush=True)
from transformers import LlavaNextProcessor, LlavaNextForConditionalGeneration
print("[DEBUG 05] transformers", flush=True)
from utils import PROMPT, parse_output, make_pairwise_deltas


# -------------------------
# Config
# -------------------------
MODEL_ID = "AdaptLLM/biomed-LLaVA-NeXT-Llama3-8B"
MODEL_TAG = "biomed_llava_next_llama3_8b"

IMG_ROOT = Path("")
OUT_DIR = Path("")
OUT_DIR.mkdir(parents=True, exist_ok=True)

DISEASES = ["acne", "benign nevus", "eczema", "psoriasis", "tinea", "vitiligo"]
IMG_EXTS = {".jpg", ".jpeg", ".png", ".webp", ".bmp", ".tif", ".tiff"}

MAX_NEW_TOKENS = 384
MAX_RETRIES = 3
DO_SAMPLE = False
TEMPERATURE = 0.0
IMAGE_MAX_SIZE = 1024

SAVE_EVERY = 10
PRINT_EVERY = 5
SHOW_OUTPUT_PREVIEW = True

RUN_ID = datetime.now().strftime("%Y%m%d_%H%M%S")

RESULTS_JSONL = OUT_DIR / f"{MODEL_TAG}_derma_raw_{RUN_ID}.jsonl"
PARSED_CSV = OUT_DIR / f"{MODEL_TAG}_derma_parsed_{RUN_ID}.csv"
PAIRED_CSV = OUT_DIR / f"{MODEL_TAG}_derma_paired_deltas_{RUN_ID}.csv"
PROGRESS_CSV = OUT_DIR / f"{MODEL_TAG}_derma_parsed_PROGRESS_{RUN_ID}.csv"
MANIFEST_CSV = OUT_DIR / f"{MODEL_TAG}_derma_manifest_{RUN_ID}.csv"

print(f"{RUN_ID} / {RESULTS_JSONL} / {PARSED_CSV}")


# -------------------------
# Helpers
# -------------------------
def append_jsonl(path, obj):
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(obj, ensure_ascii=False) + "\n")


def cleanup_cuda():
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
        torch.cuda.ipc_collect()


def extract_number(path: Path) -> int:
    m = re.search(r"_(\d+)$", path.stem)
    if not m:
        raise ValueError(f"Cannot extract numeric suffix from {path.name}")
    return int(m.group(1))


def infer_case_and_tone(path: Path):
    n = extract_number(path)
    case_index = ((n - 1) // 4) + 1
    tone_index = ((n - 1) % 4) + 1

    return (
        f"{path.parent.name}_case_{case_index:03d}",
        f"tone{tone_index}",
        tone_index,
    )


def list_images():
    rows = []

    for disease in DISEASES:
        d = IMG_ROOT / disease

        if not d.exists():
            print(f"[WARN] missing folder: {d}")
            continue

        paths = sorted(
            [p for p in d.iterdir() if p.suffix.lower() in IMG_EXTS],
            key=lambda p: extract_number(p),
        )

        for p in paths:
            case_id, tone, tone_index = infer_case_and_tone(p)

            rows.append({
                "disease_folder": disease,
                "image_path": str(p),
                "filename": p.name,
                "image_number": extract_number(p),
                "case_id": case_id,
                "tone": tone,
                "tone_index": tone_index,
            })

    return pd.DataFrame(rows)


def load_image(image_path):
    image = Image.open(image_path).convert("RGB")
    image.thumbnail((IMAGE_MAX_SIZE, IMAGE_MAX_SIZE))
    return image


def clean_response(text):
    if text is None:
        return ""

    text = text.strip()
    text = text.replace("<|endoftext|>", "")
    text = text.replace("<|im_end|>", "")
    text = text.replace("<|end|>", "")
    text = text.replace("</s>", "")
    text = text.replace("<s>", "")
    return text.strip()


def build_llava_next_instruction(prompt):
    return (
        "Follow the requested clinical output format exactly. "
        "Do not add extra sections.\n\n"
        + prompt
    )





# -------------------------
# Load BioMed LLaVA-NeXT
# -------------------------
print("\n[Load] Loading BioMed LLaVA-NeXT processor...")

processor = LlavaNextProcessor.from_pretrained(
    MODEL_ID,
    trust_remote_code=True,
)

print("[Load] Loading BioMed LLaVA-NeXT model...")

model = LlavaNextForConditionalGeneration.from_pretrained(
    MODEL_ID,
    torch_dtype=torch.bfloat16 if torch.cuda.is_available() else torch.float32,
    device_map="auto" if torch.cuda.is_available() else None,
    attn_implementation="sdpa",
    trust_remote_code=True,
)

if not torch.cuda.is_available():
    model = model.to("cpu")

# ============================================================
# Patch LLaVA-NeXT processor/model image-token alignment
# Put this immediately AFTER model loading and BEFORE model.eval()
# ============================================================

processor.patch_size = model.config.vision_config.patch_size
processor.vision_feature_select_strategy = model.config.vision_feature_select_strategy
processor.num_additional_image_tokens = 1

IMAGE_TOKEN = "<|reserved_special_token_4|>"

image_token_id = processor.tokenizer.convert_tokens_to_ids(IMAGE_TOKEN)

print("[Debug] raw image_token_id:", image_token_id)
print("[Debug] unk_token_id:", processor.tokenizer.unk_token_id)
print("[Debug] config image_token_index before:", getattr(model.config, "image_token_index", None))

if image_token_id is None or image_token_id == processor.tokenizer.unk_token_id:
    print("[Patch] adding <image> as special token")
    processor.tokenizer.add_special_tokens(
        {"additional_special_tokens": [IMAGE_TOKEN]}
    )
    model.resize_token_embeddings(len(processor.tokenizer))
    image_token_id = processor.tokenizer.convert_tokens_to_ids(IMAGE_TOKEN)

model.config.image_token_index = image_token_id

print("[Patch] processor.patch_size:", processor.patch_size)
print("[Patch] processor.vision_feature_select_strategy:", processor.vision_feature_select_strategy)
print("[Patch] processor.num_additional_image_tokens:", processor.num_additional_image_tokens)
print("[Patch] final image_token_id:", image_token_id)
print("[Patch] model image_token_index:", model.config.image_token_index)

model.eval()
model.generation_config.max_length = None
target_device = next(model.parameters()).device

print("[Load] CUDA available:", torch.cuda.is_available())
print("[Load] CUDA device count:", torch.cuda.device_count())
print("[Load] target_device:", target_device)

if torch.cuda.is_available():
    for gi in range(torch.cuda.device_count()):
        print(f"[Load] GPU {gi}:", torch.cuda.get_device_name(gi))
    print("[Load] bf16 supported:", torch.cuda.is_bf16_supported())

print("[Load] Model loaded.")


# -------------------------
# Inference
# -------------------------

def build_llava_next_instruction(prompt):
    return (
        "Follow the requested clinical output format exactly. "
        "Do not add extra sections.\n\n"
        + prompt
    )

def format_llava_next_prompt(instruction):
    image_token = "<|reserved_special_token_4|>"

    return (
        f"<|begin_of_text|><|start_header_id|>system<|end_header_id|>\n\n"
        f"You are a helpful language and vision assistant. "
        f"You are able to understand the visual content that the user provides, "
        f"and assist the user with a variety of tasks using natural language."
        f"<|eot_id|><|start_header_id|>user<|end_header_id|>\n\n"
        f"{image_token}\n{instruction}"
        f"<|eot_id|><|start_header_id|>assistant<|end_header_id|>\n\n"
    )

@torch.no_grad()
def run_model(image_path):
    image = load_image(image_path)
    instruction = build_llava_next_instruction(PROMPT)
    prompt = format_llava_next_prompt(instruction)

    # IMPORTANT:
    # Do NOT manually write "<image>" prompt.
    # Let LlavaNextProcessor insert the correct image token/chat format.
    messages = [
        {
            "role": "user",
            "content": [
                {"type": "image"},
                {"type": "text", "text": instruction},
            ],
        }
    ]


    inputs = processor(
        images=image,
        text=prompt,
        return_tensors="pt",
        padding=False,
        truncation=False,
    )

    inputs = {
        k: v.to(target_device) if torch.is_tensor(v) else v
        for k, v in inputs.items()
    }

    image_token_index = model.config.image_token_index
    n_img_tokens = int((inputs["input_ids"] == image_token_index).sum().item())
    print("[Debug] n_img_tokens:", n_img_tokens)

    answer_start = int(inputs["input_ids"].shape[-1])

    gen_kwargs = {
        "max_new_tokens": MAX_NEW_TOKENS,
        "do_sample": DO_SAMPLE,
        "pad_token_id": processor.tokenizer.eos_token_id,
    }

    if DO_SAMPLE:
        gen_kwargs["temperature"] = TEMPERATURE

    output = model.generate(
        **inputs,
        **gen_kwargs,
    )

    output_text = processor.decode(
        output[0][answer_start:],
        skip_special_tokens=True,
    ).strip()

    return clean_response(output_text)


# -------------------------
# Main
# -------------------------
manifest = list_images()
manifest.to_csv(MANIFEST_CSV, index=False)

print(f"Images found: {len(manifest)}")
print(manifest.groupby("disease_folder").size())
print(f"Manifest saved to: {MANIFEST_CSV}")
print(f"Live JSONL will be saved to: {RESULTS_JSONL}")
print(f"Progress CSV will be saved every {SAVE_EVERY} images to: {PROGRESS_CSV}")

rows = []
n_success = 0
n_error = 0
start_time = time.time()

print("Start inference...")

for i, (_, r) in enumerate(tqdm(manifest.iterrows(), total=len(manifest)), start=1):
    pct = 100 * i / len(manifest)
    last_error = None

    for attempt in range(MAX_RETRIES):
        try:
            output = run_model(r["image_path"])
            parsed = parse_output(output)

            row = {
                **r.to_dict(),
                "model_id": MODEL_ID,
                "prompt": PROMPT,
                "temperature": TEMPERATURE,
                "max_new_tokens": MAX_NEW_TOKENS,
                **parsed,
                "error": "",
            }

            append_jsonl(RESULTS_JSONL, row)
            rows.append(row)
            n_success += 1

            if SHOW_OUTPUT_PREVIEW and (i <= 3 or i % PRINT_EVERY == 0):
                print("\n" + "=" * 80)
                print(f"[{i}/{len(manifest)} | {pct:.1f}%] SUCCESS")
                print(f"file: {r['filename']}")
                print(f"disease: {r['disease_folder']} | case: {r['case_id']} | tone: {r['tone']}")
                print("-" * 80)
                print(output[:1200])
                print("=" * 80)

            break

        except torch.cuda.OutOfMemoryError as e:
            last_error = e
            cleanup_cuda()

            if attempt < MAX_RETRIES - 1:
                wait = min(90, 2 ** attempt * 5)
                print(
                    f"\n[CUDA OOM Retry] file={r['filename']} "
                    f"attempt={attempt + 1}/{MAX_RETRIES} wait={wait}s"
                )
                time.sleep(wait)
            else:
                err = traceback.format_exc()

                row = {
                    **r.to_dict(),
                    "model_id": MODEL_ID,
                    "prompt": PROMPT,
                    "temperature": TEMPERATURE,
                    "max_new_tokens": MAX_NEW_TOKENS,
                    "raw_output": "",
                    "error": err,
                }

                append_jsonl(RESULTS_JSONL, row)
                rows.append(row)
                n_error += 1

                print("\n" + "!" * 80)
                print(f"[{i}/{len(manifest)} | {pct:.1f}%] FAILED CUDA OOM")
                print(f"file: {r['filename']}")
                print(f"error: {repr(last_error)}")
                print("!" * 80)

        except Exception as e:
            last_error = e
            cleanup_cuda()

            if attempt < MAX_RETRIES - 1:
                wait = min(90, 2 ** attempt * 5)
                print(
                    f"\n[Retry] file={r['filename']} "
                    f"attempt={attempt + 1}/{MAX_RETRIES} "
                    f"error={repr(e)} wait={wait}s"
                )
                time.sleep(wait)
            else:
                err = traceback.format_exc()

                row = {
                    **r.to_dict(),
                    "model_id": MODEL_ID,
                    "prompt": PROMPT,
                    "temperature": TEMPERATURE,
                    "max_new_tokens": MAX_NEW_TOKENS,
                    "raw_output": "",
                    "error": err,
                }

                append_jsonl(RESULTS_JSONL, row)
                rows.append(row)
                n_error += 1

                print("\n" + "!" * 80)
                print(f"[{i}/{len(manifest)} | {pct:.1f}%] FAILED")
                print(f"file: {r['filename']}")
                print(f"error: {repr(e)}")
                print("!" * 80)

    if i % SAVE_EVERY == 0:
        tmp_df = pd.DataFrame(rows)
        tmp_df.to_csv(PROGRESS_CSV, index=False)

        elapsed = time.time() - start_time
        avg_sec = elapsed / max(i, 1)

        print("\n" + "-" * 80)
        print(f"[PROGRESS SAVE] {i}/{len(manifest)} = {pct:.1f}%")

        print("\n" + "-" * 80)
        print(f"[PROGRESS SAVE] {i}/{len(manifest)} = {pct:.1f}%")
        print(f"success: {n_success} | errors: {n_error}")
        print(f"avg sec/image: {avg_sec:.2f}")
        print(f"saved: {PROGRESS_CSV}")
        print(f"jsonl live file: {RESULTS_JSONL}")
        print("-" * 80)


# -------------------------
# Final save
# -------------------------
df = pd.DataFrame(rows)

df.to_csv(PARSED_CSV, index=False)
df.to_csv(PROGRESS_CSV, index=False)

delta_df = make_pairwise_deltas(df)
delta_df.to_csv(PAIRED_CSV, index=False)

print("\nDONE")
print(f"Raw JSONL:      {RESULTS_JSONL}")
print(f"Parsed CSV:     {PARSED_CSV}")
print(f"Progress CSV:   {PROGRESS_CSV}")
print(f"Paired deltas:  {PAIRED_CSV}")

print("\nQuick summary:")
print("Rows:", len(df))

if len(df) > 0:
    print("Cases:", df[["disease_folder", "case_id"]].drop_duplicates().shape[0])

print("Success:", n_success)
print("Errors:", n_error)

if len(delta_df) > 0:
    print("\nDiagnosis flip rate:")
    print(delta_df["diagnosis_flip"].mean())

    delta_cols = [c for c in delta_df.columns if c.startswith("delta_")]

    print("\nMean paired deltas:")
    print(
        delta_df[delta_cols]
        .mean(numeric_only=True)
        .sort_values(ascending=False)
        .head(20)
    )
