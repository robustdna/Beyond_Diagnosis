#!/usr/bin/env python3
# ============================================================
# Dermatology Skin-tone Perturbation Audit
# MedGemma Version
#
# Uses:
#   utils.py
#     - PROMPT
#     - parse_output
#     - make_pairwise_deltas
#
# Before running:
#   huggingface-cli login
#   or
#   export HF_TOKEN="hf_xxxxxxxxx"
# ============================================================

import os
import re
import json
import time
import traceback
from pathlib import Path
from datetime import datetime

print("[DEBUG 00] datetime", flush=True)

import torch
print("[DEBUG 01] torch", flush=True)

import pandas as pd
print("[DEBUG 02] pandas", flush=True)

from tqdm import tqdm
print("[DEBUG 03] tqdm", flush=True)

from PIL import Image
print("[DEBUG 04] PIL", flush=True)

from transformers import AutoProcessor, AutoModelForImageTextToText
print("[DEBUG 05] transformers", flush=True)

from utils import PROMPT, parse_output, make_pairwise_deltas


# -------------------------
# Config
# -------------------------
MODEL_ID = "google/medgemma-1.5-4b-it"
MODEL_TAG = "medgemma_1_5_4b_it"

IMG_ROOT = Path("")
OUT_DIR = Path("")
OUT_DIR.mkdir(parents=True, exist_ok=True)

DISEASES = ["acne", "benign nevus", "eczema", "psoriasis", "tinea", "vitiligo"]
IMG_EXTS = {".jpg", ".jpeg", ".png", ".webp", ".bmp", ".tif", ".tiff"}

MAX_NEW_TOKENS = 384
MAX_RETRIES = 3
DO_SAMPLE = False
TEMPERATURE = 0.0
IMAGE_MAX_SIZE = 1024

SAVE_EVERY = 10
PRINT_EVERY = 5
SHOW_OUTPUT_PREVIEW = True

RUN_ID = datetime.now().strftime("%Y%m%d_%H%M%S")

RESULTS_JSONL = OUT_DIR / f"{MODEL_TAG}_derma_raw_{RUN_ID}.jsonl"
PARSED_CSV = OUT_DIR / f"{MODEL_TAG}_derma_parsed_{RUN_ID}.csv"
PAIRED_CSV = OUT_DIR / f"{MODEL_TAG}_derma_paired_deltas_{RUN_ID}.csv"
PROGRESS_CSV = OUT_DIR / f"{MODEL_TAG}_derma_parsed_PROGRESS_{RUN_ID}.csv"
MANIFEST_CSV = OUT_DIR / f"{MODEL_TAG}_derma_manifest_{RUN_ID}.csv"

print(f"{RUN_ID} / {RESULTS_JSONL} / {PARSED_CSV}")


# -------------------------
# Helpers
# -------------------------
def append_jsonl(path, obj):
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(obj, ensure_ascii=False) + "\n")


def cleanup_cuda():
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
        try:
            torch.cuda.ipc_collect()
        except Exception:
            pass


def extract_number(path: Path) -> int:
    m = re.search(r"_(\d+)$", path.stem)
    if not m:
        raise ValueError(f"Cannot extract numeric suffix from {path.name}")
    return int(m.group(1))


def infer_case_and_tone(path: Path):
    n = extract_number(path)
    case_index = ((n - 1) // 4) + 1
    tone_index = ((n - 1) % 4) + 1

    return (
        f"{path.parent.name}_case_{case_index:03d}",
        f"tone{tone_index}",
        tone_index,
    )


def list_images():
    rows = []

    for disease in DISEASES:
        d = IMG_ROOT / disease

        if not d.exists():
            print(f"[WARN] missing folder: {d}")
            continue

        paths = sorted(
            [p for p in d.iterdir() if p.suffix.lower() in IMG_EXTS],
            key=lambda p: extract_number(p),
        )

        for p in paths:
            case_id, tone, tone_index = infer_case_and_tone(p)

            rows.append({
                "disease_folder": disease,
                "image_path": str(p),
                "filename": p.name,
                "image_number": extract_number(p),
                "case_id": case_id,
                "tone": tone,
                "tone_index": tone_index,
            })

    return pd.DataFrame(rows)


def load_image(image_path):
    image = Image.open(image_path).convert("RGB")
    image.thumbnail((IMAGE_MAX_SIZE, IMAGE_MAX_SIZE))
    return image


def clean_response(text):
    if text is None:
        return ""

    text = text.strip()
    for tok in [
        "<|endoftext|>",
        "<|im_end|>",
        "<|end|>",
        "</s>",
        "<s>",
        "<end_of_turn>",
    ]:
        text = text.replace(tok, "")

    return text.strip()


def build_medgemma_instruction(prompt):
    return (
        "Follow the requested clinical output format exactly. "
        "Do not add extra sections.\n\n"
        + prompt
    )


# -------------------------
# HF token / gated model check
# -------------------------
HF_TOKEN = os.environ.get("HF_TOKEN", None)

print("[HF] HF_TOKEN env exists:", HF_TOKEN is not None)
print("[HF] If loading fails with 401/403, accept the MedGemma terms on Hugging Face first.")


# -------------------------
# Load MedGemma
# -------------------------
print("\n[Load] Loading MedGemma processor...")

processor = AutoProcessor.from_pretrained(
    MODEL_ID,
    token=HF_TOKEN,
)

print("[Load] Loading MedGemma model...")

model = AutoModelForImageTextToText.from_pretrained(
    MODEL_ID,
    torch_dtype=torch.bfloat16 if torch.cuda.is_available() else torch.float32,
    device_map="auto" if torch.cuda.is_available() else None,
    token=HF_TOKEN,
)

if not torch.cuda.is_available():
    model = model.to("cpu")

model.eval()

print("[Load] CUDA available:", torch.cuda.is_available())
print("[Load] CUDA device count:", torch.cuda.device_count())

if torch.cuda.is_available():
    for gi in range(torch.cuda.device_count()):
        print(f"[Load] GPU {gi}:", torch.cuda.get_device_name(gi))
    print("[Load] bf16 supported:", torch.cuda.is_bf16_supported())

try:
    target_device = next(model.parameters()).device
except StopIteration:
    target_device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

print("[Load] target_device:", target_device)
print("[Load] Model loaded.")


# -------------------------
# Inference
# -------------------------
@torch.no_grad()
def run_model(image_path):
    image = load_image(image_path)
    instruction = build_medgemma_instruction(PROMPT)

    messages = [
        {
            "role": "system",
            "content": [
                {
                    "type": "text",
                    "text": (
                        "You are a careful medical vision-language assistant. "
                        "Analyze the provided dermatology image and follow the user's output format exactly."
                    ),
                }
            ],
        },
        {
            "role": "user",
            "content": [
                {"type": "image", "image": image},
                {"type": "text", "text": instruction},
            ],
        },
    ]

    inputs = processor.apply_chat_template(
        messages,
        add_generation_prompt=True,
        tokenize=True,
        return_dict=True,
        return_tensors="pt",
    )

    if torch.cuda.is_available():
        inputs = inputs.to(model.device, dtype=torch.bfloat16)
    else:
        inputs = inputs.to(model.device)

    answer_start = int(inputs["input_ids"].shape[-1])

    gen_kwargs = {
        "max_new_tokens": MAX_NEW_TOKENS,
        "do_sample": DO_SAMPLE,
        "pad_token_id": processor.tokenizer.eos_token_id,
    }

    if DO_SAMPLE:
        gen_kwargs["temperature"] = TEMPERATURE

    output = model.generate(
        **inputs,
        **gen_kwargs,
    )

    output_text = processor.decode(
        output[0][answer_start:],
        skip_special_tokens=True,
    ).strip()

    return clean_response(output_text)


# -------------------------
# Main
# -------------------------
manifest = list_images()
manifest.to_csv(MANIFEST_CSV, index=False)

print(f"Images found: {len(manifest)}")

if len(manifest) > 0:
    print(manifest.groupby("disease_folder").size())

print(f"Manifest saved to: {MANIFEST_CSV}")
print(f"Live JSONL will be saved to: {RESULTS_JSONL}")
print(f"Progress CSV will be saved every {SAVE_EVERY} images to: {PROGRESS_CSV}")

rows = []
n_success = 0
n_error = 0
start_time = time.time()

print("Start inference...")

for i, (_, r) in enumerate(tqdm(manifest.iterrows(), total=len(manifest)), start=1):
    pct = 100 * i / max(len(manifest), 1)
    last_error = None

    for attempt in range(MAX_RETRIES):
        try:
            output = run_model(r["image_path"])
            parsed = parse_output(output)

            row = {
                **r.to_dict(),
                "model_id": MODEL_ID,
                "prompt": PROMPT,
                "temperature": TEMPERATURE,
                "max_new_tokens": MAX_NEW_TOKENS,
                "raw_output": output,
                **parsed,
                "error": "",
            }

            append_jsonl(RESULTS_JSONL, row)
            rows.append(row)
            n_success += 1

            if SHOW_OUTPUT_PREVIEW and (i <= 3 or i % PRINT_EVERY == 0):
                print("\n" + "=" * 80)
                print(f"[{i}/{len(manifest)} | {pct:.1f}%] SUCCESS")
                print(f"file: {r['filename']}")
                print(f"disease: {r['disease_folder']} | case: {r['case_id']} | tone: {r['tone']}")
                print("-" * 80)
                print(output[:1200])
                print("=" * 80)

            break

        except torch.cuda.OutOfMemoryError as e:
            last_error = e
            cleanup_cuda()

            if attempt < MAX_RETRIES - 1:
                wait = min(90, 2 ** attempt * 5)
                print(
                    f"\n[CUDA OOM Retry] file={r['filename']} "
                    f"attempt={attempt + 1}/{MAX_RETRIES} wait={wait}s"
                )
                time.sleep(wait)
            else:
                err = traceback.format_exc()

                row = {
                    **r.to_dict(),
                    "model_id": MODEL_ID,
                    "prompt": PROMPT,
                    "temperature": TEMPERATURE,
                    "max_new_tokens": MAX_NEW_TOKENS,
                    "raw_output": "",
                    "error": err,
                }

                append_jsonl(RESULTS_JSONL, row)
                rows.append(row)
                n_error += 1

                print("\n" + "!" * 80)
                print(f"[{i}/{len(manifest)} | {pct:.1f}%] FAILED CUDA OOM")
                print(f"file: {r['filename']}")
                print(f"error: {repr(last_error)}")
                print("!" * 80)

        except Exception as e:
            last_error = e
            cleanup_cuda()

            if attempt < MAX_RETRIES - 1:
                wait = min(90, 2 ** attempt * 5)
                print(
                    f"\n[Retry] file={r['filename']} "
                    f"attempt={attempt + 1}/{MAX_RETRIES} "
                    f"error={repr(e)} wait={wait}s"
                )
                time.sleep(wait)
            else:
                err = traceback.format_exc()

                row = {
                    **r.to_dict(),
                    "model_id": MODEL_ID,
                    "prompt": PROMPT,
                    "temperature": TEMPERATURE,
                    "max_new_tokens": MAX_NEW_TOKENS,
                    "raw_output": "",
                    "error": err,
                }

                append_jsonl(RESULTS_JSONL, row)
                rows.append(row)
                n_error += 1

                print("\n" + "!" * 80)
                print(f"[{i}/{len(manifest)} | {pct:.1f}%] FAILED")
                print(f"file: {r['filename']}")
                print(f"error: {repr(e)}")
                print("!" * 80)

    if i % SAVE_EVERY == 0:
        tmp_df = pd.DataFrame(rows)
        tmp_df.to_csv(PROGRESS_CSV, index=False)

        elapsed = time.time() - start_time
        avg_sec = elapsed / max(i, 1)

        print("\n" + "-" * 80)
        print(f"[PROGRESS SAVE] {i}/{len(manifest)} = {pct:.1f}%")
        print(f"success: {n_success} | errors: {n_error}")
        print(f"avg sec/image: {avg_sec:.2f}")
        print(f"saved: {PROGRESS_CSV}")
        print(f"jsonl live file: {RESULTS_JSONL}")
        print("-" * 80)


# -------------------------
# Final save
# -------------------------
df = pd.DataFrame(rows)

df.to_csv(PARSED_CSV, index=False)
df.to_csv(PROGRESS_CSV, index=False)

delta_df = make_pairwise_deltas(df)
delta_df.to_csv(PAIRED_CSV, index=False)

print("\nDONE")
print(f"Raw JSONL:      {RESULTS_JSONL}")
print(f"Parsed CSV:     {PARSED_CSV}")
print(f"Progress CSV:   {PROGRESS_CSV}")
print(f"Paired deltas:  {PAIRED_CSV}")

print("\nQuick summary:")
print("Rows:", len(df))

if len(df) > 0:
    print("Cases:", df[["disease_folder", "case_id"]].drop_duplicates().shape[0])

print("Success:", n_success)
print("Errors:", n_error)

if len(delta_df) > 0:
    print("\nDiagnosis flip rate:")
    print(delta_df["diagnosis_flip"].mean())

    delta_cols = [c for c in delta_df.columns if c.startswith("delta_")]

    print("\nMean paired deltas:")
    print(
        delta_df[delta_cols]
        .mean(numeric_only=True)
        .sort_values(ascending=False)
        .head(20)
    )
