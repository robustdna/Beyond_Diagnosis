#!/usr/bin/env python3
# ============================================================
# Dermatology Skin-tone Perturbation Audit
# DeepSeek-VL2 Version
#
# Uses:
#   utils.py
#     - PROMPT
#     - parse_output
#     - make_pairwise_deltas
# ============================================================

import os
import re
import json
import time
import traceback
from pathlib import Path
from datetime import datetime

import torch
import pandas as pd
from tqdm import tqdm
from PIL import Image

from transformers import AutoModelForCausalLM
from deepseek_vl2.models import DeepseekVLV2Processor
from deepseek_vl2.utils.io import load_pil_images

from utils import PROMPT, parse_output, make_pairwise_deltas


# -------------------------
# Config
# -------------------------
MODEL_ID = "deepseek-ai/deepseek-vl2"
# MODEL_ID = "deepseek-ai/deepseek-vl2-small"
# MODEL_ID = "deepseek-ai/deepseek-vl2-tiny"

MODEL_TAG = "deepseek_vl2"

IMG_ROOT = Path("")
OUT_DIR = Path("")
OUT_DIR.mkdir(parents=True, exist_ok=True)

DISEASES = ["acne", "benign nevus", "eczema", "psoriasis", "tinea", "vitiligo"]
IMG_EXTS = {".jpg", ".jpeg", ".png", ".webp", ".bmp", ".tif", ".tiff"}

MAX_NEW_TOKENS = 384
MAX_RETRIES = 3
DO_SAMPLE = False
TEMPERATURE = 0.0
IMAGE_MAX_SIZE = 1024

SAVE_EVERY = 10
PRINT_EVERY = 5
SHOW_OUTPUT_PREVIEW = True

RUN_ID = datetime.now().strftime("%Y%m%d_%H%M%S")

RESULTS_JSONL = OUT_DIR / f"{MODEL_TAG}_derma_raw_{RUN_ID}.jsonl"
PARSED_CSV = OUT_DIR / f"{MODEL_TAG}_derma_parsed_{RUN_ID}.csv"
PAIRED_CSV = OUT_DIR / f"{MODEL_TAG}_derma_paired_deltas_{RUN_ID}.csv"
PROGRESS_CSV = OUT_DIR / f"{MODEL_TAG}_derma_parsed_PROGRESS_{RUN_ID}.csv"
MANIFEST_CSV = OUT_DIR / f"{MODEL_TAG}_derma_manifest_{RUN_ID}.csv"

print(f"{RUN_ID} / {RESULTS_JSONL} / {PARSED_CSV}")


# -------------------------
# Helpers
# -------------------------
def append_jsonl(path, obj):
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(obj, ensure_ascii=False) + "\n")


def cleanup_cuda():
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
        torch.cuda.ipc_collect()


def extract_number(path: Path) -> int:
    m = re.search(r"_(\d+)$", path.stem)
    if not m:
        raise ValueError(f"Cannot extract numeric suffix from {path.name}")
    return int(m.group(1))


def infer_case_and_tone(path: Path):
    n = extract_number(path)
    case_index = ((n - 1) // 4) + 1
    tone_index = ((n - 1) % 4) + 1

    return (
        f"{path.parent.name}_case_{case_index:03d}",
        f"tone{tone_index}",
        tone_index,
    )


def list_images():
    rows = []

    for disease in DISEASES:
        d = IMG_ROOT / disease

        if not d.exists():
            print(f"[WARN] missing folder: {d}")
            continue

        paths = sorted(
            [p for p in d.iterdir() if p.suffix.lower() in IMG_EXTS],
            key=lambda p: extract_number(p),
        )

        for p in paths:
            case_id, tone, tone_index = infer_case_and_tone(p)

            rows.append({
                "disease_folder": disease,
                "image_path": str(p),
                "filename": p.name,
                "image_number": extract_number(p),
                "case_id": case_id,
                "tone": tone,
                "tone_index": tone_index,
            })

    return pd.DataFrame(rows)


def resize_image_inplace(image_path):
    """
    DeepSeek-VL2 uses load_pil_images(conversation), which reads from path.
    To keep the original files untouched, this function does NOT overwrite them.
    It is kept here only for naming consistency.
    """
    return str(image_path)


def clean_deepseek_response(text):
    if text is None:
        return ""

    text = text.strip()
    text = text.replace("<|endoftext|>", "")
    text = text.replace("<|im_end|>", "")
    text = text.replace("<|end|>", "")
    text = text.replace("<|Assistant|>", "")
    text = text.replace("<|User|>", "")
    return text.strip()


def build_deepseek_prompt(prompt):
    return (
        "Follow the requested clinical output format exactly. "
        "Do not add extra sections.\n\n"
        + prompt
    )


def build_deepseek_conversation(image_path, prompt):
    image_path = str(image_path)

    return [
        {
            "role": "<|User|>",
            "content": f"<image>\n{prompt}",
            "images": [image_path],
        },
        {
            "role": "<|Assistant|>",
            "content": "",
        },
    ]


# -------------------------
# Load DeepSeek-VL2
# -------------------------
print("\n[Load] Loading DeepSeek-VL2 processor...")

vl_chat_processor: DeepseekVLV2Processor = DeepseekVLV2Processor.from_pretrained(
    MODEL_ID
)
tokenizer = vl_chat_processor.tokenizer

print("[Load] Loading DeepSeek-VL2 model...")

vl_gpt = AutoModelForCausalLM.from_pretrained(
    MODEL_ID,
    trust_remote_code=True,
    torch_dtype=torch.bfloat16 if torch.cuda.is_available() else torch.float32,
    device_map="auto" if torch.cuda.is_available() else None,
)

if not torch.cuda.is_available():
    vl_gpt = vl_gpt.to("cpu")

vl_gpt.eval()

target_device = next(vl_gpt.parameters()).device

print("[Load] CUDA available:", torch.cuda.is_available())
print("[Load] CUDA device count:", torch.cuda.device_count())
print("[Load] target_device:", target_device)

if torch.cuda.is_available():
    for gi in range(torch.cuda.device_count()):
        print(f"[Load] GPU {gi}:", torch.cuda.get_device_name(gi))
    print("[Load] bf16 supported:", torch.cuda.is_bf16_supported())

print("[Load] Model loaded.")


# -------------------------
# Inference
# -------------------------
@torch.no_grad()
def run_model(image_path):
    prompt = build_deepseek_prompt(PROMPT)
    conversation = build_deepseek_conversation(image_path, prompt)

    pil_images = load_pil_images(conversation)

    prepare_inputs = vl_chat_processor(
        conversations=conversation,
        images=pil_images,
        force_batchify=True,
        system_prompt="",
    )

    prepare_inputs = prepare_inputs.to(target_device)

    inputs_embeds = vl_gpt.prepare_inputs_embeds(**prepare_inputs)

    gen_kwargs = {
        "inputs_embeds": inputs_embeds,
        "attention_mask": prepare_inputs.attention_mask,
        "pad_token_id": tokenizer.eos_token_id,
        "bos_token_id": tokenizer.bos_token_id,
        "eos_token_id": tokenizer.eos_token_id,
        "max_new_tokens": MAX_NEW_TOKENS,
        "do_sample": DO_SAMPLE,
        "use_cache": False,
    }

    if DO_SAMPLE:
        gen_kwargs["temperature"] = TEMPERATURE

    outputs = vl_gpt.language.generate(**gen_kwargs)

    output_text = tokenizer.decode(
        outputs[0].cpu().tolist(),
        skip_special_tokens=True,
    ).strip()

    if "<|Assistant|>" in output_text:
        output_text = output_text.split("<|Assistant|>")[-1].strip()

    return clean_deepseek_response(output_text)


# -------------------------
# Main
# -------------------------
manifest = list_images()
manifest.to_csv(MANIFEST_CSV, index=False)

print(f"Images found: {len(manifest)}")
print(manifest.groupby("disease_folder").size())
print(f"Manifest saved to: {MANIFEST_CSV}")
print(f"Live JSONL will be saved to: {RESULTS_JSONL}")
print(f"Progress CSV will be saved every {SAVE_EVERY} images to: {PROGRESS_CSV}")

rows = []
n_success = 0
n_error = 0
start_time = time.time()

print("Start inference...")

for i, (_, r) in enumerate(tqdm(manifest.iterrows(), total=len(manifest)), start=1):
    pct = 100 * i / len(manifest)
    last_error = None

    for attempt in range(MAX_RETRIES):
        try:
            output = run_model(r["image_path"])
            parsed = parse_output(output)

            row = {
                **r.to_dict(),
                "model_id": MODEL_ID,
                "prompt": PROMPT,
                "temperature": TEMPERATURE,
                "max_new_tokens": MAX_NEW_TOKENS,
                **parsed,
                "error": "",
            }

            append_jsonl(RESULTS_JSONL, row)
            rows.append(row)
            n_success += 1

            if SHOW_OUTPUT_PREVIEW and (i <= 3 or i % PRINT_EVERY == 0):
                print("\n" + "=" * 80)
                print(f"[{i}/{len(manifest)} | {pct:.1f}%] SUCCESS")
                print(f"file: {r['filename']}")
                print(f"disease: {r['disease_folder']} | case: {r['case_id']} | tone: {r['tone']}")
                print("-" * 80)
                print(output[:1200])
                print("=" * 80)

            break

        except torch.cuda.OutOfMemoryError as e:
            last_error = e
            cleanup_cuda()

            if attempt < MAX_RETRIES - 1:
                wait = min(90, 2 ** attempt * 5)
                print(
                    f"\n[CUDA OOM Retry] file={r['filename']} "
                    f"attempt={attempt + 1}/{MAX_RETRIES} wait={wait}s"
                )
                time.sleep(wait)
            else:
                err = traceback.format_exc()

                row = {
                    **r.to_dict(),
                    "model_id": MODEL_ID,
                    "prompt": PROMPT,
                    "temperature": TEMPERATURE,
                    "max_new_tokens": MAX_NEW_TOKENS,
                    "raw_output": "",
                    "error": err,
                }

                append_jsonl(RESULTS_JSONL, row)
                rows.append(row)
                n_error += 1

                print("\n" + "!" * 80)
                print(f"[{i}/{len(manifest)} | {pct:.1f}%] FAILED CUDA OOM")
                print(f"file: {r['filename']}")
                print(f"error: {repr(last_error)}")
                print("!" * 80)

        except Exception as e:
            last_error = e
            cleanup_cuda()

            if attempt < MAX_RETRIES - 1:
                wait = min(90, 2 ** attempt * 5)
                print(
                    f"\n[Retry] file={r['filename']} "
                    f"attempt={attempt + 1}/{MAX_RETRIES} "
                    f"error={repr(e)} wait={wait}s"
                )
                time.sleep(wait)
            else:
                err = traceback.format_exc()

                row = {
                    **r.to_dict(),
                    "model_id": MODEL_ID,
                    "prompt": PROMPT,
                    "temperature": TEMPERATURE,
                    "max_new_tokens": MAX_NEW_TOKENS,
                    "raw_output": "",
                    "error": err,
                }

                append_jsonl(RESULTS_JSONL, row)
                rows.append(row)
                n_error += 1

                print("\n" + "!" * 80)
                print(f"[{i}/{len(manifest)} | {pct:.1f}%] FAILED")
                print(f"file: {r['filename']}")
                print(f"error: {repr(e)}")
                print("!" * 80)

    if i % SAVE_EVERY == 0:
        tmp_df = pd.DataFrame(rows)
        tmp_df.to_csv(PROGRESS_CSV, index=False)

        elapsed = time.time() - start_time
        avg_sec = elapsed / max(i, 1)

        print("\n" + "-" * 80)
        print(f"[PROGRESS SAVE] {i}/{len(manifest)} = {pct:.1f}%")
        print(f"success: {n_success} | errors: {n_error}")
        print(f"avg sec/image: {avg_sec:.2f}")
        print(f"saved: {PROGRESS_CSV}")
        print(f"jsonl live file: {RESULTS_JSONL}")
        print("-" * 80)


# -------------------------
# Final save
# -------------------------
df = pd.DataFrame(rows)

df.to_csv(PARSED_CSV, index=False)
df.to_csv(PROGRESS_CSV, index=False)

delta_df = make_pairwise_deltas(df)
delta_df.to_csv(PAIRED_CSV, index=False)

print("\nDONE")
print(f"Raw JSONL:      {RESULTS_JSONL}")
print(f"Parsed CSV:     {PARSED_CSV}")
print(f"Progress CSV:   {PROGRESS_CSV}")
print(f"Paired deltas:  {PAIRED_CSV}")

print("\nQuick summary:")
print("Rows:", len(df))

if len(df) > 0:
    print("Cases:", df[["disease_folder", "case_id"]].drop_duplicates().shape[0])

print("Success:", n_success)
print("Errors:", n_error)

if len(delta_df) > 0:
    print("\nDiagnosis flip rate:")
    print(delta_df["diagnosis_flip"].mean())

    delta_cols = [c for c in delta_df.columns if c.startswith("delta_")]

    print("\nMean paired deltas:")
    print(
        delta_df[delta_cols]
        .mean(numeric_only=True)
        .sort_values(ascending=False)
        .head(20)
    )
