#!/usr/bin/env python3
# ============================================================
# Dermatology Skin-tone Perturbation Audit
# GPT-5.4 mini Version
#
# Requires:
#   pip install openai pandas pillow tqdm
#
# Uses:
#   utils.py
#     - PROMPT
#     - parse_output
#     - make_pairwise_deltas
#
# Before running:
#   export OPENAI_API_KEY="sk-..."
# ============================================================

import os
import re
import io
import json
import time
import base64
import traceback
from pathlib import Path
from datetime import datetime

import pandas as pd
from PIL import Image
from tqdm import tqdm

from openai import OpenAI

from utils import PROMPT, parse_output, make_pairwise_deltas


# -------------------------
# Config
# -------------------------
MODEL_ID = "gpt-5.4-mini"
MODEL_TAG = "gpt54mini"

IMG_ROOT = Path("")
OUT_DIR = Path("")
OUT_DIR.mkdir(parents=True, exist_ok=True)

DISEASES = ["acne", "benign nevus", "eczema", "psoriasis", "tinea", "vitiligo"]
IMG_EXTS = {".jpg", ".jpeg", ".png", ".webp", ".bmp", ".tif", ".tiff"}

MAX_OUTPUT_TOKENS = 700
MAX_RETRIES = 4
IMAGE_MAX_SIZE = 1024
JPEG_QUALITY = 90

SAVE_EVERY = 10
PRINT_EVERY = 5
SHOW_OUTPUT_PREVIEW = True
SLEEP_BETWEEN_CALLS = 0.25

RUN_ID = datetime.now().strftime("%Y%m%d_%H%M%S")

RESULTS_JSONL = OUT_DIR / f"{MODEL_TAG}_derma_raw_{RUN_ID}.jsonl"
FAILED_JSONL = OUT_DIR / f"{MODEL_TAG}_derma_failed_{RUN_ID}.jsonl"
PARSED_CSV = OUT_DIR / f"{MODEL_TAG}_derma_parsed_{RUN_ID}.csv"
PAIRED_CSV = OUT_DIR / f"{MODEL_TAG}_derma_paired_deltas_{RUN_ID}.csv"
PROGRESS_CSV = OUT_DIR / f"{MODEL_TAG}_derma_parsed_PROGRESS_{RUN_ID}.csv"
MANIFEST_CSV = OUT_DIR / f"{MODEL_TAG}_derma_manifest_{RUN_ID}.csv"

print("MODEL:", MODEL_ID)
print("RUN_ID:", RUN_ID)
print("RESULTS:", RESULTS_JSONL)


# -------------------------
# OpenAI client
# -------------------------
OPENAI_API_KEY = ""

if not OPENAI_API_KEY:
    raise RuntimeError(
        "no OPENAI_API_KEY"
    )

client = OpenAI(api_key=OPENAI_API_KEY)


# -------------------------
# Helpers
# -------------------------
def append_jsonl(path, obj):
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(obj, ensure_ascii=False) + "\n")


def extract_number(path: Path) -> int:
    m = re.search(r"_(\d+)$", path.stem)
    if not m:
        raise ValueError(f"Cannot extract numeric suffix from {path.name}")
    return int(m.group(1))


def infer_case_and_tone(path: Path):
    n = extract_number(path)
    case_index = ((n - 1) // 4) + 1
    tone_index = ((n - 1) % 4) + 1

    return (
        f"{path.parent.name}_case_{case_index:03d}",
        f"tone{tone_index}",
        tone_index,
    )


def list_images():
    rows = []

    for disease in DISEASES:
        d = IMG_ROOT / disease

        if not d.exists():
            print(f"[WARN] missing folder: {d}")
            continue

        paths = sorted(
            [p for p in d.iterdir() if p.suffix.lower() in IMG_EXTS],
            key=lambda p: extract_number(p),
        )

        for p in paths:
            case_id, tone, tone_index = infer_case_and_tone(p)

            rows.append({
                "disease_folder": disease,
                "image_path": str(p),
                "filename": p.name,
                "image_number": extract_number(p),
                "case_id": case_id,
                "tone": tone,
                "tone_index": tone_index,
            })

    return pd.DataFrame(rows)


def image_to_data_url(image_path, max_size=IMAGE_MAX_SIZE, quality=JPEG_QUALITY):
    img = Image.open(image_path).convert("RGB")
    img.thumbnail((max_size, max_size))

    buf = io.BytesIO()
    img.save(buf, format="JPEG", quality=quality)

    b64 = base64.b64encode(buf.getvalue()).decode("utf-8")
    return f"data:image/jpeg;base64,{b64}"


def clean_response(text):
    if text is None:
        return ""

    text = text.strip()

    for tok in [
        "<|endoftext|>",
        "<|im_end|>",
        "<|end|>",
        "</s>",
        "<s>",
        "<end_of_turn>",
    ]:
        text = text.replace(tok, "")

    return text.strip()


def build_gpt_instruction(prompt):
    return (
        "You are a careful medical vision-language assistant. "
        "Analyze the provided dermatology image. "
        "Follow the requested clinical output format exactly. "
        "Do not add extra sections. "
        "Return only the requested answer format.\n\n"
        + prompt
    )


def load_existing_done(results_path):
    if not results_path.exists() or results_path.stat().st_size == 0:
        return [], set()

    rows = []

    with open(results_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                rows.append(json.loads(line))
            except Exception:
                print("[Resume] skipped broken JSONL line")

    done = set()

    for row in rows:
        if row.get("error", "") == "":
            done.add(row.get("image_path"))

    return rows, done


# -------------------------
# GPT inference
# -------------------------
def run_model_once(image_path):
    instruction = build_gpt_instruction(PROMPT)

    content = [
        {
            "type": "input_text",
            "text": instruction,
        },
        {
            "type": "input_image",
            "image_url": image_to_data_url(image_path),
        },
    ]

    response = client.responses.create(
        model=MODEL_ID,
        input=[
            {
                "role": "user",
                "content": content,
            }
        ],
        max_output_tokens=MAX_OUTPUT_TOKENS,
    )

    return clean_response(response.output_text)


def run_model(image_path, max_retries=MAX_RETRIES):
    last_error = None

    for attempt in range(max_retries):
        try:
            return run_model_once(image_path)

        except Exception as e:
            last_error = e
            wait = min(90, 2 ** attempt * 5)

            print(
                f"\n[Retry] file={Path(image_path).name} "
                f"attempt={attempt + 1}/{max_retries} "
                f"error={repr(e)} wait={wait}s"
            )

            time.sleep(wait)

    raise last_error


# -------------------------
# Main
# -------------------------
def main():
    manifest = list_images()
    manifest.to_csv(MANIFEST_CSV, index=False)

    print(f"Images found: {len(manifest)}")

    if len(manifest) > 0:
        print(manifest.groupby("disease_folder").size())

    print(f"Manifest saved to: {MANIFEST_CSV}")
    print(f"Live JSONL will be saved to: {RESULTS_JSONL}")
    print(f"Progress CSV will be saved every {SAVE_EVERY} images to: {PROGRESS_CSV}")

    existing_rows, done = load_existing_done(RESULTS_JSONL)
    rows = existing_rows.copy()

    n_success = sum(1 for r in rows if r.get("error", "") == "")
    n_error = sum(1 for r in rows if r.get("error", "") != "")

    print("\n=== Resume status ===")
    print("Existing successful rows:", n_success)
    print("Existing error rows:", n_error)
    print("Remaining:", len(manifest) - len(done))

    start_time = time.time()

    print("\nStart inference...")

    for i, (_, r) in enumerate(tqdm(manifest.iterrows(), total=len(manifest)), start=1):
        image_path = r["image_path"]
        pct = 100 * i / max(len(manifest), 1)

        if image_path in done:
            continue

        try:
            output = run_model(image_path)
            parsed = parse_output(output)

            row = {
                **r.to_dict(),
                "model_id": MODEL_ID,
                "prompt": PROMPT,
                "max_output_tokens": MAX_OUTPUT_TOKENS,
                "raw_output": output,
                **parsed,
                "error": "",
            }

            append_jsonl(RESULTS_JSONL, row)
            rows.append(row)
            done.add(image_path)
            n_success += 1

            if SHOW_OUTPUT_PREVIEW and (i <= 3 or i % PRINT_EVERY == 0):
                print("\n" + "=" * 80)
                print(f"[{i}/{len(manifest)} | {pct:.1f}%] SUCCESS")
                print(f"file: {r['filename']}")
                print(f"disease: {r['disease_folder']} | case: {r['case_id']} | tone: {r['tone']}")
                print("-" * 80)
                print(output[:1200])
                print("=" * 80)

            time.sleep(SLEEP_BETWEEN_CALLS)

        except Exception as e:
            err = traceback.format_exc()

            row = {
                **r.to_dict(),
                "model_id": MODEL_ID,
                "prompt": PROMPT,
                "max_output_tokens": MAX_OUTPUT_TOKENS,
                "raw_output": "",
                "error": err,
            }

            append_jsonl(RESULTS_JSONL, row)
            append_jsonl(FAILED_JSONL, row)
            rows.append(row)
            n_error += 1

            print("\n" + "!" * 80)
            print(f"[{i}/{len(manifest)} | {pct:.1f}%] FAILED")
            print(f"file: {r['filename']}")
            print(f"error: {repr(e)}")
            print("!" * 80)

            time.sleep(3)

        if i % SAVE_EVERY == 0:
            tmp_df = pd.DataFrame(rows)
            tmp_df.to_csv(PROGRESS_CSV, index=False)

            elapsed = time.time() - start_time
            avg_sec = elapsed / max(i, 1)

            print("\n" + "-" * 80)
            print(f"[PROGRESS SAVE] {i}/{len(manifest)} = {pct:.1f}%")
            print(f"success: {n_success} | errors: {n_error}")
            print(f"avg sec/image: {avg_sec:.2f}")
            print(f"saved: {PROGRESS_CSV}")
            print(f"jsonl live file: {RESULTS_JSONL}")
            print("-" * 80)

    # -------------------------
    # Final save
    # -------------------------
    df = pd.DataFrame(rows)

    if len(df) > 0:
        df = df.drop_duplicates(subset=["image_path"], keep="last").copy()

    df.to_csv(PARSED_CSV, index=False)
    df.to_csv(PROGRESS_CSV, index=False)

    ok_df = df[df["error"].fillna("") == ""].copy()

    delta_df = make_pairwise_deltas(ok_df)
    delta_df.to_csv(PAIRED_CSV, index=False)

    print("\nDONE")
    print(f"Raw JSONL:      {RESULTS_JSONL}")
    print(f"Failed JSONL:   {FAILED_JSONL}")
    print(f"Parsed CSV:     {PARSED_CSV}")
    print(f"Progress CSV:   {PROGRESS_CSV}")
    print(f"Paired deltas:  {PAIRED_CSV}")

    print("\nQuick summary:")
    print("Rows:", len(df))

    if len(df) > 0:
        print("Cases:", df[["disease_folder", "case_id"]].drop_duplicates().shape[0])

    print("Success:", n_success)
    print("Errors:", n_error)

    if len(delta_df) > 0 and "diagnosis_flip" in delta_df.columns:
        print("\nDiagnosis flip rate:")
        print(delta_df["diagnosis_flip"].mean())

        delta_cols = [c for c in delta_df.columns if c.startswith("delta_")]

        if delta_cols:
            print("\nMean paired deltas:")
            print(
                delta_df[delta_cols]
                .mean(numeric_only=True)
                .sort_values(ascending=False)
                .head(20)
            )


if __name__ == "__main__":
    main()
